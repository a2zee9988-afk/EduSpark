# EduSpark Android project

This is an Android Studio project wrapping the supplied EduSpark web app in a native Android WebView. App assets are bundled locally under `app/src/main/assets`, so lessons and progress tracking run without hosting the website. Google Fonts may require an internet connection.

## Build an APK
1. Open this folder in Android Studio (recent version).
2. Allow Gradle sync and install Android SDK Platform 35 if prompted.
3. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. The debug APK will be at `app/build/outputs/apk/debug/app-debug.apk`.

Package: `com.eduspark.app`  
Minimum Android: 6.0 (API 23)
