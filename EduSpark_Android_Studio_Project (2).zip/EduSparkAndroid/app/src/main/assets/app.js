// EduSpark App - Educational Learning Platform
const DATA = {
  topics: [
    { id: 'math', name: 'Mathematics', icon: '➕', color: '#3b82f6', lessons: 3, desc: 'Numbers, algebra basics & problem solving' },
    { id: 'science', name: 'Science', icon: '⚛️', color: '#10b981', lessons: 3, desc: 'Physics, biology & chemistry fundamentals' },
    { id: 'geo', name: 'Geography', icon: '🌍', color: '#f59e0b', lessons: 2, desc: 'Continents, countries & world facts' },
    { id: 'tech', name: 'Technology & AI', icon: '</>', color: '#8b5cf6', lessons: 3, desc: 'How computers & AI work' }
  ],
  lessons: {
    math: [
      { id: 'm1', title: 'What is Algebra?', content: 'Algebra uses letters (variables) to represent unknown numbers. For example, x + 3 = 7 means we need to find the number that, when added to 3, equals 7. The answer is 4. Algebra helps us solve real-world problems systematically.', duration: '3 min' },
      { id: 'm2', title: 'Order of Operations', content: 'Remember PEMDAS: Parentheses, Exponents, Multiplication & Division (left to right), Addition & Subtraction (left to right). Example: 2 + 3 × 4 = 2 + 12 = 14, not 20.', duration: '2 min' },
      { id: 'm3', title: 'Fractions Basics', content: 'A fraction has a numerator (top) and denominator (bottom). 1/2 means one part out of two equal parts. To add fractions with the same denominator, just add the numerators: 1/4 + 2/4 = 3/4.', duration: '3 min' }
    ],
    science: [
      { id: 's1', title: 'States of Matter', content: 'Matter exists in three main states: solid, liquid, and gas. Solids have fixed shape, liquids take the shape of their container, and gases expand to fill any space. Water is a classic example that can be ice (solid), water (liquid), or steam (gas).', duration: '3 min' },
      { id: 's2', title: 'Photosynthesis', content: 'Plants make their own food using sunlight, water, and carbon dioxide. The process is called photosynthesis and produces oxygen as a byproduct. This is why forests are called the lungs of the Earth.', duration: '3 min' },
      { id: 's3', title: 'Newton\'s Laws', content: 'Newton\'s First Law: An object at rest stays at rest unless acted upon by a force. Second Law: Force = mass × acceleration. Third Law: Every action has an equal and opposite reaction.', duration: '4 min' }
    ],
    geo: [
      { id: 'g1', title: 'Continents of the World', content: 'There are 7 continents: Asia (largest), Africa, North America, South America, Antarctica, Europe, and Australia/Oceania. Asia contains over 60% of the world\'s population.', duration: '2 min' },
      { id: 'g2', title: 'Climate Zones', content: 'Earth has major climate zones: tropical (near equator, hot & wet), temperate (moderate seasons), and polar (cold). Climate is influenced by latitude, altitude, and ocean currents.', duration: '3 min' }
    ],
    tech: [
      { id: 't1', title: 'What is AI?', content: 'Artificial Intelligence (AI) is when computers perform tasks that normally require human intelligence — like recognizing images, understanding language, or making decisions. Modern AI learns from large amounts of data.', duration: '3 min' },
      { id: 't2', title: 'How the Internet Works', content: 'The Internet is a global network of computers connected by cables and wireless signals. When you visit a website, your device sends a request to a server, which sends back the page data. Protocols like HTTP make this communication possible.', duration: '3 min' },
      { id: 't3', title: 'Algorithms', content: 'An algorithm is a step-by-step set of instructions to solve a problem. Search engines use algorithms to rank results. Sorting a list of names is also an algorithm. Good algorithms are efficient and correct.', duration: '2 min' }
    ]
  },
  quizzes: {
    math: [
      { q: 'What is 7 + 8?', options: ['14', '15', '16', '13'], answer: 1 },
      { q: 'Solve: x + 5 = 12', options: ['5', '7', '6', '8'], answer: 1 },
      { q: 'What is 3 × 4 + 2?', options: ['14', '18', '20', '15'], answer: 0 }
    ],
    science: [
      { q: 'What gas do plants release during photosynthesis?', options: ['Carbon dioxide', 'Oxygen', 'Nitrogen', 'Hydrogen'], answer: 1 },
      { q: 'Water turning into ice is an example of:', options: ['Melting', 'Evaporation', 'Freezing', 'Condensation'], answer: 2 },
      { q: 'Newton\'s Third Law is about:', options: ['Inertia', 'F=ma', 'Action-reaction', 'Gravity'], answer: 2 }
    ],
    geo: [
      { q: 'Which is the largest continent?', options: ['Africa', 'Asia', 'Europe', 'North America'], answer: 1 },
      { q: 'How many continents are there?', options: ['5', '6', '7', '8'], answer: 2 }
    ],
    tech: [
      { q: 'What does AI stand for?', options: ['Automated Internet', 'Artificial Intelligence', 'Advanced Interface', 'Algorithmic Integration'], answer: 1 },
      { q: 'What protocol is commonly used for websites?', options: ['FTP', 'HTTP', 'SMTP', 'SSH'], answer: 1 },
      { q: 'An algorithm is:', options: ['A type of computer', 'Step-by-step instructions', 'A programming language', 'Internet cable'], answer: 1 }
    ]
  }
};

const BADGES = [
  { id: 'first_lesson', name: 'First Spark', desc: 'Complete your first lesson', icon: '✨' },
  { id: 'quiz_master', name: 'Quiz Master', desc: 'Score 100% on a quiz', icon: '🏆' },
  { id: 'streak_3', name: 'On Fire', desc: '3-day learning streak', icon: '🔥' },
  { id: 'all_topics', name: 'Explorer', desc: 'Try all subjects', icon: '🧭' }
];

class EduSpark {
  constructor() {
    this.user = this.loadUser();
    this.currentPage = 'home';
    this.currentTopic = null;
    this.currentLesson = null;
    this.currentQuiz = null;
    this.quizIndex = 0;
    this.quizScore = 0;
    this.init();
  }

  loadUser() {
    const saved = localStorage.getItem('eduspark_user');
    if (saved) return JSON.parse(saved);
    return {
      name: '',
      points: 0,
      streak: 0,
      lastVisit: null,
      completedLessons: [],
      quizScores: {},
      badges: [],
      theme: 'light'
    };
  }

  saveUser() {
    localStorage.setItem('eduspark_user', JSON.stringify(this.user));
    this.updateHeader();
  }

  init() {
    // Theme
    if (this.user.theme === 'dark' || (this.user.theme === 'auto' && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
      document.documentElement.setAttribute('data-theme', 'dark');
    }
    this.updateHeader();
    this.setupNav();
    this.showPage('home');
    this.checkStreak();
    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.register('sw.js').catch(() => {});
    }
  }

  updateHeader() {
    document.getElementById('points-display').textContent = `${this.user.points} pts`;
    document.getElementById('streak-display').textContent = `🔥 ${this.user.streak}`;
  }

  checkStreak() {
    const today = new Date().toDateString();
    if (this.user.lastVisit !== today) {
      const yesterday = new Date(Date.now() - 86400000).toDateString();
      if (this.user.lastVisit === yesterday) {
        this.user.streak += 1;
      } else if (this.user.lastVisit) {
        this.user.streak = 1;
      } else {
        this.user.streak = 1;
      }
      this.user.lastVisit = today;
      this.checkBadges();
      this.saveUser();
    }
  }

  setupNav() {
    document.querySelectorAll('.nav-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        document.querySelectorAll('.nav-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        this.showPage(btn.dataset.page);
      });
    });
    document.getElementById('theme-toggle').addEventListener('click', () => this.toggleTheme());
  }

  toggleTheme() {
    const isDark = document.documentElement.getAttribute('data-theme') === 'dark';
    document.documentElement.setAttribute('data-theme', isDark ? 'light' : 'dark');
    this.user.theme = isDark ? 'light' : 'dark';
    document.getElementById('theme-toggle').textContent = isDark ? '🌙' : '☀️';
    this.saveUser();
  }

  showPage(page) {
    this.currentPage = page;
    const main = document.getElementById('main-content');
    if (page === 'home') main.innerHTML = this.renderHome();
    else if (page === 'learn') main.innerHTML = this.renderLearn();
    else if (page === 'quiz') main.innerHTML = this.renderQuizSelect();
    else if (page === 'profile') main.innerHTML = this.renderProfile();
  }

  renderHome() {
    const completed = this.user.completedLessons.length;
    const total = Object.values(DATA.lessons).flat().length;
    const pct = total ? Math.round((completed / total) * 100) : 0;
    return `
      <div class="hero">
        <img src="hero.jpg" alt="Students learning">
        <div class="hero-text">
          <h1>Welcome to EduSpark</h1>
          <p>Learn smarter with interactive lessons and quizzes.</p>
        </div>
      </div>
      <div class="card">
        <h3>Your Progress</h3>
        <p>${completed} of ${total} lessons completed</p>
        <div class="progress-bar"><div class="progress-fill" style="width:${pct}%"></div></div>
        <p style="font-size:0.85rem;color:var(--text-muted)">${pct}% complete</p>
      </div>
      <div class="card">
        <h3>Continue Learning</h3>
        <button class="btn" onclick="app.showPage('learn')">Browse Topics</button>
        <button class="btn btn-secondary" onclick="app.showPage('quiz')">Take a Quiz</button>
      </div>
      <div class="card">
        <h3>Daily Streak</h3>
        <p style="font-size:1.5rem">🔥 ${this.user.streak} days</p>
        <p style="color:var(--text-muted);font-size:0.9rem">Keep learning every day!</p>
      </div>
    `;
  }

  renderLearn() {
    return `
      <h2 style="margin-bottom:16px">Choose a Topic</h2>
      <div class="topic-grid">
        ${DATA.topics.map(t => `
          <div class="topic-card" onclick="app.openTopic('${t.id}')">
            <div class="topic-icon">${t.icon}</div>
            <h3>${t.name}</h3>
            <p style="font-size:0.8rem;color:var(--text-muted)">${t.lessons} lessons</p>
          </div>
        `).join('')}
      </div>
    `;
  }

  openTopic(id) {
    this.currentTopic = id;
    const topic = DATA.topics.find(t => t.id === id);
    const lessons = DATA.lessons[id];
    const main = document.getElementById('main-content');
    main.innerHTML = `
      <button class="btn btn-secondary" style="margin-bottom:16px" onclick="app.showPage('learn')">← Back</button>
      <h2>${topic.icon} ${topic.name}</h2>
      <p style="color:var(--text-muted);margin-bottom:16px">${topic.desc}</p>
      ${lessons.map(l => {
        const done = this.user.completedLessons.includes(l.id);
        return `
          <div class="card" onclick="app.openLesson('${id}','${l.id}')" style="cursor:pointer">
            <div style="display:flex;justify-content:space-between;align-items:center">
              <div>
                <h3>${l.title} ${done ? '✅' : ''}</h3>
                <p style="font-size:0.85rem;color:var(--text-muted)">${l.duration}</p>
              </div>
              <span>→</span>
            </div>
          </div>
        `;
      }).join('')}
    `;
  }

  openLesson(topicId, lessonId) {
    const lesson = DATA.lessons[topicId].find(l => l.id === lessonId);
    this.currentLesson = lesson;
    const main = document.getElementById('main-content');
    main.innerHTML = `
      <button class="btn btn-secondary" style="margin-bottom:16px" onclick="app.openTopic('${topicId}')">← Back</button>
      <div class="card">
        <h2>${lesson.title}</h2>
        <p style="margin:12px 0;line-height:1.6">${lesson.content}</p>
        <button class="btn" onclick="app.completeLesson('${lessonId}')">Mark as Complete (+10 pts)</button>
      </div>
    `;
  }

  completeLesson(id) {
    if (!this.user.completedLessons.includes(id)) {
      this.user.completedLessons.push(id);
      this.user.points += 10;
      this.checkBadges();
      this.saveUser();
      alert('Lesson completed! +10 points');
    }
    this.openTopic(this.currentTopic);
  }

  renderQuizSelect() {
    return `
      <h2 style="margin-bottom:16px">Choose a Quiz</h2>
      ${DATA.topics.map(t => `
        <div class="card" onclick="app.startQuiz('${t.id}')" style="cursor:pointer">
          <h3>${t.icon} ${t.name} Quiz</h3>
          <p style="color:var(--text-muted);font-size:0.9rem">${DATA.quizzes[t.id].length} questions</p>
        </div>
      `).join('')}
    `;
  }

  startQuiz(topicId) {
    this.currentQuiz = DATA.quizzes[topicId];
    this.quizIndex = 0;
    this.quizScore = 0;
    this.showQuizQuestion();
  }

  showQuizQuestion() {
    if (this.quizIndex >= this.currentQuiz.length) {
      this.finishQuiz();
      return;
    }
    const q = this.currentQuiz[this.quizIndex];
    const main = document.getElementById('main-content');
    main.innerHTML = `
      <div class="card">
        <p style="color:var(--text-muted);margin-bottom:8px">Question ${this.quizIndex + 1} of ${this.currentQuiz.length}</p>
        <h3 style="margin-bottom:16px">${q.q}</h3>
        ${q.options.map((opt, i) => `
          <button class="quiz-option" onclick="app.answerQuiz(${i})">${opt}</button>
        `).join('')}
      </div>
    `;
  }

  answerQuiz(choice) {
    const q = this.currentQuiz[this.quizIndex];
    const correct = choice === q.answer;
    if (correct) this.quizScore++;
    const options = document.querySelectorAll('.quiz-option');
    options.forEach((opt, i) => {
      opt.disabled = true;
      if (i === q.answer) opt.classList.add('correct');
      else if (i === choice && !correct) opt.classList.add('wrong');
    });
    setTimeout(() => {
      this.quizIndex++;
      this.showQuizQuestion();
    }, 800);
  }

  finishQuiz() {
    const pct = Math.round((this.quizScore / this.currentQuiz.length) * 100);
    const points = this.quizScore * 5;
    this.user.points += points;
    if (pct === 100) this.user.badges.push('quiz_master');
    this.checkBadges();
    this.saveUser();
    const main = document.getElementById('main-content');
    main.innerHTML = `
      <div class="card" style="text-align:center">
        <h2>Quiz Complete!</h2>
        <p style="font-size:2rem;margin:16px 0">${pct}%</p>
        <p>You scored ${this.quizScore} / ${this.currentQuiz.length}</p>
        <p style="color:var(--success);font-weight:600;margin:8px 0">+${points} points</p>
        <button class="btn" onclick="app.showPage('quiz')">Try Another Quiz</button>
        <button class="btn btn-secondary" onclick="app.showPage('home')">Back to Home</button>
      </div>
    `;
  }

  renderProfile() {
    const badges = BADGES.filter(b => this.user.badges.includes(b.id));
    return `
      <div class="card">
        <h2>Profile</h2>
        <label>Your Name</label>
        <input class="input" id="name-input" value="${this.user.name}" placeholder="Enter your name">
        <button class="btn" onclick="app.saveName()">Save Name</button>
      </div>
      <div class="card">
        <h3>Stats</h3>
        <p>Total Points: <strong>${this.user.points}</strong></p>
        <p>Lessons Completed: <strong>${this.user.completedLessons.length}</strong></p>
        <p>Current Streak: <strong>${this.user.streak} days</strong></p>
      </div>
      <div class="card">
        <h3>Badges</h3>
        ${badges.length ? badges.map(b => `<span class="badge">${b.icon} ${b.name}</span>`).join('') : '<p style="color:var(--text-muted)">Complete lessons and quizzes to earn badges!</p>'}
      </div>
      <div class="card">
        <button class="btn btn-secondary" onclick="app.resetProgress()">Reset Progress</button>
      </div>
    `;
  }

  saveName() {
    const name = document.getElementById('name-input').value.trim();
    this.user.name = name;
    this.saveUser();
    alert('Name saved!');
  }

  checkBadges() {
    if (this.user.completedLessons.length >= 1 && !this.user.badges.includes('first_lesson')) {
      this.user.badges.push('first_lesson');
    }
    if (this.user.streak >= 3 && !this.user.badges.includes('streak_3')) {
      this.user.badges.push('streak_3');
    }
    const topicsTried = new Set(this.user.completedLessons.map(id => id[0]));
    if (topicsTried.size >= 4 && !this.user.badges.includes('all_topics')) {
      this.user.badges.push('all_topics');
    }
  }

  resetProgress() {
    if (confirm('Reset all progress? This cannot be undone.')) {
      localStorage.removeItem('eduspark_user');
      location.reload();
    }
  }
}

const app = new EduSpark();
